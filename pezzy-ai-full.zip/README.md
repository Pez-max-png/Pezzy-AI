# Pezzy AI — starter website

This is a Next.js starter project based on the code supplied in chat. It includes a responsive landing page, tool selector, text-to-image API route scaffold, premium pricing page, login placeholder, and Prisma schema.

## Requirements
- Node.js 20 or newer
- A Replicate API token for image generation
- Optional remove.bg API key for background removal

## Run locally
1. Extract the ZIP.
2. Copy `.env.example` to `.env`.
3. Add your real API credentials. Do not publish `.env` or commit it to Git.
4. Run:

```bash
npm install
npx prisma generate
npx prisma db push
npm run dev
```

5. Open `http://localhost:3000`.

## Important before launch
- The login page is only a placeholder. Secure email/password or Google authentication is not yet wired up.
- The premium page displays ₦2,500/month, but checkout is intentionally disabled until Paystack is implemented with server-side transaction verification and authenticated users.
- The current image tools for cartoon, upscale, and OCR are not implemented yet.
- Configure a persistent production database before deployment. SQLite is suitable for local development but generally not the right choice for serverless production.
- Verify the Replicate model slug and input/output format against the model's current documentation before launch.
- Add rate limiting, upload size/type validation, abuse protection, privacy policy, and terms before making this public.

## Deploy
You can deploy this project on a compatible Next.js host such as Vercel. You must connect your own hosting account and set environment variables there. Deployment and domain ownership cannot be completed from this ZIP alone.
