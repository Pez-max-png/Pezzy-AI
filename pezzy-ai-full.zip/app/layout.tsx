import "./globals.css";
export const metadata = {
  title: "Pezzy AI — Make your ideas visual",
  description: "Create, transform, and explore images with Pezzy AI."
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
