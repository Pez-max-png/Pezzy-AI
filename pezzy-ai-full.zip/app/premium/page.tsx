export default function Premium() {
  return (
    <main className="flex min-h-screen items-center justify-center px-5 py-12">
      <div className="w-full max-w-lg rounded-3xl border border-violet-400/20 bg-white/[0.04] p-8 sm:p-10">
        <a href="/" className="text-sm text-zinc-400 hover:text-white">← Back to Pezzy AI</a>
        <div className="mt-6 text-sm font-semibold text-violet-300">PEZZY AI PREMIUM ✦</div>
        <h1 className="mt-3 text-4xl font-black">Create without limits.</h1>
        <p className="mt-3 text-zinc-400">Premium plan concept — subscription checkout must be securely connected before accepting payments.</p>
        <div className="my-8"><span className="text-5xl font-black">₦2,500</span><span className="text-zinc-400"> / month</span></div>
        <ul className="space-y-3 text-sm text-zinc-200">
          <li>✓ Premium image tools</li><li>✓ More generation access</li><li>✓ Ad-free experience</li><li>✓ Faster creative workflow</li>
        </ul>
        <button disabled className="mt-8 w-full cursor-not-allowed rounded-2xl bg-violet-600/50 px-5 py-4 font-bold">Payments not connected yet</button>
        <p className="mt-4 text-xs leading-5 text-zinc-500">Do not enter payment details until Paystack checkout, server-side payment verification, and user accounts have been implemented.</p>
      </div>
    </main>
  );
}
