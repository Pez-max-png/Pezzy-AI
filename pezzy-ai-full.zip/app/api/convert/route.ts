import { NextResponse } from "next/server";
import Replicate from "replicate";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const { image, tool, prompt } = await req.json();

    if (tool === "generate") {
      if (!prompt || typeof prompt !== "string") {
        return NextResponse.json({ error: "Please enter an image description." }, { status: 400 });
      }
      if (!process.env.REPLICATE_API_TOKEN) {
        return NextResponse.json({
          error: "Image generation is not connected yet. Add REPLICATE_API_TOKEN to your .env file."
        }, { status: 503 });
      }
      const replicate = new Replicate({ auth: process.env.REPLICATE_API_TOKEN });
      // Example model endpoint. Check Replicate for a currently supported model/version
      // and update this model identifier/input schema if it changes.
      const output = await replicate.run("black-forest-labs/flux-schnell", {
        input: { prompt, num_outputs: 1, aspect_ratio: "1:1", output_format: "webp" }
      });
      const first = Array.isArray(output) ? output[0] : output;
      return NextResponse.json({ url: typeof first === "string" ? first : String(first) });
    }

    if (!image || typeof image !== "string") {
      return NextResponse.json({ error: "Upload an image first." }, { status: 400 });
    }

    if (tool === "bg-remove") {
      if (!process.env.REMOVE_BG_API_KEY) {
        return NextResponse.json({ error: "Background removal is not configured. Add REMOVE_BG_API_KEY." }, { status: 503 });
      }
      const form = new FormData();
      form.append("image_file_b64", image.split(",")[1] || image);
      form.append("size", "auto");
      const res = await fetch("https://api.remove.bg/v1.0/removebg", {
        method: "POST",
        headers: { "X-Api-Key": process.env.REMOVE_BG_API_KEY },
        body: form
      });
      if (!res.ok) return NextResponse.json({ error: "Background removal failed. Check your API key and account quota." }, { status: 502 });
      const buffer = Buffer.from(await res.arrayBuffer()).toString("base64");
      return NextResponse.json({ url: `data:image/png;base64,${buffer}` });
    }

    return NextResponse.json({
      error: `The "${tool}" tool needs its own processing model before it can be used.`
    }, { status: 501 });
  } catch (error) {
    console.error("Pezzy AI API error:", error);
    return NextResponse.json({ error: "The request failed. Check server configuration and API logs." }, { status: 500 });
  }
}
