"use client";
import { useState } from "react";

const tools = [
  { id: "generate", label: "Text to image" },
  { id: "bg-remove", label: "Remove background" },
  { id: "cartoon", label: "Cartoon style" },
  { id: "upscale", label: "HD upscale" },
  { id: "ocr", label: "Read text (OCR)" }
];

export default function Home() {
  const [tool, setTool] = useState("generate");
  const [prompt, setPrompt] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function runTool() {
    setMessage("");
    if (tool === "generate" && !prompt.trim()) {
      setMessage("Describe the image you want to create first.");
      return;
    }
    if (tool !== "generate" && !image) {
      setMessage("Upload an image first for this tool.");
      return;
    }
    setLoading(true);
    setResult(null);
    try {
      const response = await fetch("/api/convert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tool, prompt, image })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Something went wrong.");
      if (data.premiumRequired) {
        window.location.href = "/premium";
        return;
      }
      setResult(data.url || null);
      setMessage(data.message || "");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Request failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-6">
        <a href="/" className="text-2xl font-black tracking-tight">PEZZY <span className="text-violet-400">AI</span></a>
        <div className="flex items-center gap-3">
          <a href="/login" className="rounded-full border border-white/15 px-4 py-2 text-sm hover:bg-white/5">Log in</a>
          <a href="/premium" className="rounded-full bg-violet-600 px-4 py-2 text-sm font-semibold hover:bg-violet-500">Go Premium ✦</a>
        </div>
      </nav>

      <section className="mx-auto max-w-5xl px-5 pb-20 pt-12 text-center sm:pt-20">
        <div className="mb-5 inline-flex rounded-full border border-violet-400/30 bg-violet-400/10 px-4 py-2 text-xs text-violet-200">YOUR IDEAS, REIMAGINED</div>
        <h1 className="text-4xl font-black leading-tight sm:text-7xl">Imagine it.<br/><span className="bg-gradient-to-r from-violet-300 to-fuchsia-400 bg-clip-text text-transparent">Create it with AI.</span></h1>
        <p className="mx-auto mt-5 max-w-2xl text-base text-zinc-400 sm:text-lg">Create stunning visuals from a prompt, or transform an image you already love.</p>

        <div className="mx-auto mt-10 max-w-3xl rounded-3xl border border-white/10 bg-white/[0.035] p-4 text-left shadow-2xl shadow-violet-950/20 sm:p-7">
          <div className="flex flex-wrap gap-2">
            {tools.map(t => <button key={t.id} onClick={() => {setTool(t.id); setMessage("");}} className={`rounded-full px-4 py-2 text-sm transition ${tool === t.id ? "bg-violet-600 text-white" : "bg-white/5 text-zinc-300 hover:bg-white/10"}`}>{t.label}</button>)}
          </div>

          {tool === "generate" ? (
            <label className="mt-5 block">
              <span className="mb-2 block text-sm text-zinc-300">Describe your image</span>
              <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={4} placeholder="A cinematic portrait of a Nigerian astronaut standing in a glowing futuristic Lagos at sunset..." className="w-full resize-y rounded-2xl border border-white/10 bg-black/40 p-4 outline-none placeholder:text-zinc-600 focus:border-violet-400"/>
            </label>
          ) : (
            <div className="mt-5 rounded-2xl border border-dashed border-white/20 p-6">
              <label className="block cursor-pointer text-center">
                <span className="text-lg font-semibold">Upload an image</span>
                <span className="mt-1 block text-sm text-zinc-400">Choose a JPG, PNG, or WebP image from your device.</span>
                <input className="mt-4 block w-full text-sm text-zinc-300" type="file" accept="image/*" onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) { const reader = new FileReader(); reader.onload = () => setImage(reader.result as string); reader.readAsDataURL(f); }
                }}/>
              </label>
              {image && <img src={image} alt="Selected upload" className="mx-auto mt-5 max-h-64 rounded-xl"/>}
            </div>
          )}

          <button onClick={runTool} disabled={loading} className="mt-5 w-full rounded-2xl bg-white px-6 py-4 font-bold text-black transition hover:bg-violet-100 disabled:cursor-wait disabled:opacity-60">
            {loading ? "Working on it…" : tool === "generate" ? "Generate image ✨" : "Transform image ✨"}
          </button>
          {message && <p role="status" className="mt-4 text-sm text-amber-200">{message}</p>}
          {result && <div className="mt-7 text-center"><img src={result} alt="AI result" className="mx-auto max-h-[600px] rounded-2xl"/><a href={result} download="pezzy-ai-result.png" className="mt-4 inline-block rounded-full bg-violet-600 px-6 py-3 font-semibold">Download result</a></div>}
        </div>

        <div className="mt-12 grid gap-4 text-left sm:grid-cols-3">
          {[["✦","Create from text","Turn an idea into a visual."],["◈","Transform images","Explore creative image tools."],["♛","Premium access","More freedom, fewer interruptions."]].map(([icon,title,desc]) => <div key={title} className="rounded-2xl border border-white/10 bg-white/[0.025] p-5"><div className="text-2xl text-violet-300">{icon}</div><h3 className="mt-3 font-bold">{title}</h3><p className="mt-1 text-sm text-zinc-400">{desc}</p></div>)}
        </div>
        <p className="mt-12 text-xs text-zinc-600">Pezzy AI · Built for your imagination</p>
      </section>
    </main>
  );
}
