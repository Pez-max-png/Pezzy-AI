export default function Login() {
  return (
    <main className="flex min-h-screen items-center justify-center px-5">
      <div className="w-full max-w-md rounded-3xl border border-white/10 bg-white/[0.04] p-8">
        <a href="/" className="text-sm text-zinc-400">← Back</a>
        <h1 className="mt-5 text-3xl font-black">Welcome to Pezzy AI</h1>
        <p className="mt-2 text-sm text-zinc-400">Account sign-in is a placeholder in this starter project.</p>
        <label className="mt-6 block text-sm">Email<input type="email" autoComplete="email" placeholder="you@example.com" className="mt-2 w-full rounded-xl border border-white/10 bg-black/30 p-3 outline-none focus:border-violet-400"/></label>
        <label className="mt-4 block text-sm">Password<input type="password" autoComplete="current-password" placeholder="Your password" className="mt-2 w-full rounded-xl border border-white/10 bg-black/30 p-3 outline-none focus:border-violet-400"/></label>
        <button disabled className="mt-6 w-full cursor-not-allowed rounded-xl bg-violet-600/50 p-3 font-bold">Authentication not connected</button>
        <p className="mt-4 text-xs text-zinc-500">Do not collect real passwords until secure authentication is implemented.</p>
      </div>
    </main>
  );
}
